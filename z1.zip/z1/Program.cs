﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace z1
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = "file.txt";
            if (!File.Exists(filePath))
            {
                Console.WriteLine("Файл не найден!");
                return;
            }
            var reversedLines = File.ReadAllLines(filePath).Select(line => new string(line.Reverse().ToArray()));
            foreach (var line in reversedLines)
            {
                Console.WriteLine(line);
            }
            Console.ReadKey();
        }
    }
}
