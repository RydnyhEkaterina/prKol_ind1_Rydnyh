﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.IO;

namespace Z1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string filePath = textBox1.Text;
                if (!File.Exists(filePath))
                {
                    MessageBox.Show("Файл не найден!");
                    return;
                }

                string formula = File.ReadAllText(filePath).Trim();
                int result = Calculate(formula);
                label1.Text = result.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private int Calculate(string formula)
        {
            Stack<int> valueStack = new Stack<int>();
            Stack<char> operatorStack = new Stack<char>();
            formula = formula.Replace(" ", "").Replace("=", "");

            for (int i = 0; i < formula.Length; i++)
            {
                char c = formula[i];

                if (char.IsDigit(c))
                {
                    valueStack.Push(c - '0');
                }
                else if (c == 'M' || c == 'm')
                {
                    operatorStack.Push(c);
                    i++;
                }
                else if (c == ',')
                {
                    continue;
                }
                else if (c == '(')
                {
                    continue;
                }
                else if (c == ')')
                {
                    if (operatorStack.Count == 0 || valueStack.Count < 2)
                    {
                        throw new ArgumentException("Некорректная формула: несоответствие операторов и операндов");
                    }

                    char op = operatorStack.Pop();
                    int operand2 = valueStack.Pop();
                    int operand1 = valueStack.Pop();

                    int result = op == 'M'
                        ? Math.Max(operand1, operand2)
                        : Math.Min(operand1, operand2);

                    valueStack.Push(result);
                }
                else
                {
                    throw new ArgumentException($"Недопустимый символ в формуле: '{c}'");
                }
            }

            if (valueStack.Count != 1 || operatorStack.Count != 0)
            {
                throw new ArgumentException("Некорректная формула: несоответствие операторов и операндов");
            }

            return valueStack.Pop();
        }
    }
}